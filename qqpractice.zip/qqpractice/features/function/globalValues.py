"""
全局变量
"""
class globalValues:
    userID = ''
    text = ''