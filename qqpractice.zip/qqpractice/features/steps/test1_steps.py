from behave import *

use_step_matcher('re')


@step('login111 (.*)')
def step_impl(context,text):
    context.test1_page.login111(text)

@step('search (.*)')
def step_impl(context,text):
    context.test1_page.search(text)

@step('open (.*)nd good')
def step_impl(context,condition):
    context.test1_page.open_good(condition)