from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from features.browser import Browser
from features.function.Log import logger
from features.function import CommonFunction
from features.function.globalValues import globalValues

class test1(Browser):
    def reset_driver(self,driver):
        global py_web_driver
        py_web_driver = driver
        # self.CommonFunction =CommonFunction(py_web_driver)

    def __init__(self):
        global py_web_driver
        py_web_driver = self.driver
        global test_url
        test_url = self.url

    def login111(self,text):
        py_web_driver.get(test_url)
        logger.info(text)
        print(text)
        if text.lower() == "default":
            globalValues.text = "淘宝网"
            WebDriverWait(py_web_driver,60).until(EC.element_to_be_clickable((By.XPATH,'//input[contains(@value, "百度一下")]/../preceding-sibling::span[1]/input'))).send_keys(globalValues.text)
        else:
            self.click_element('//input[contains(@value, "百度一下")]/../preceding-sibling::span[1]/input',text)
        WebDriverWait(py_web_driver,30,0.5).until(EC.element_to_be_clickable((By.XPATH,'//input[contains(@value, "百度一下")]'))).click()
        WebDriverWait(py_web_driver, 30, 0.5).until(EC.element_to_be_clickable((By.XPATH, '//*[contains(text(), "搜索结果涉及价格仅作参考，请以商家官网为准")]/following-sibling::div/descendant::h3/descendant::a'))).click()

        CommonFunction.switch_cur_handle(py_web_driver)



    def search(self,text):
        logger.info(f'Let us search {text}')
        self.input_keys('//*[@id="J_search_key"]',text)
        self.click_element('//*[@id="J_searchForm"]/input')

    def open_good(self,condition):
        logger.info(f'Open the {condition}nd good')
        self.click_element('(//*[@data-lazy-collect="1"])['+ condition +']')